package com.datacampus.biohealth2.controller;

public class ShowHealthInformationController {
}
